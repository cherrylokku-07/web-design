<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = ""; // Assuming no password is set
$dbname = "movie_database";
?>
